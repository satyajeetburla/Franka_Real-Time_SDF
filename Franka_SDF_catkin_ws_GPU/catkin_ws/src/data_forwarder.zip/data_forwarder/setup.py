#!/usr/bin/env python

from setuptools import setup

setup(
    name='data_forwarder',
    version='0.1.0',
    packages=['data_forwarder'],
    scripts=['src/data_forwarder.py'],
    install_requires=['rospy', 'std_msgs', 'sensor_msgs'],
    author='Your Name',
    author_email='your.email@example.com',
    maintainer='Your Name',
    maintainer_email='your.email@example.com',
    description='ROS package for data forwarding',
    license='MIT',
    entry_points={
        'console_scripts': [
            'data_forwarder = data_forwarder.data_forwarder:main'
        ],
    },
)

