#!/usr/bin/env python

import rospy
from std_msgs.msg import String

class DataForwarder:
    def __init__(self):
        rospy.init_node('data_forwarder', anonymous=True)
        rospy.Subscriber('data_topic', String, self.data_callback)
        self.pub = rospy.Publisher('data_topic', String, queue_size=10)

    def data_callback(self, msg):
        # Callback function to receive data and forward it to the slave PC
        self.pub.publish(msg)

if __name__ == '__main__':
    try:
        data_forwarder = DataForwarder()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass

