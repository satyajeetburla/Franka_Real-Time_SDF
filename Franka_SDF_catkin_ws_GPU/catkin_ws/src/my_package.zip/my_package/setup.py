from setuptools import setup

package_name = 'my_package'  # Replace 'my_package' with the actual name of your package

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    scripts=[
        'src/master_talker.py',
        'src/slave_listener.py'
    ],
    install_requires=[
        'rospy',
        'std_msgs',
        'sensor_msgs'
    ],
    author='Your Name',
    author_email='your.email@example.com',
    maintainer='Your Name',
    maintainer_email='your.email@example.com',
    description='Your package description',
    license='MIT'
)

