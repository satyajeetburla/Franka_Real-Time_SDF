#!/usr/bin/env python

import rospy
from sensor_msgs.msg import Image

def callback_color(data):
    rospy.loginfo("Received Color Image from Master")
    # Process the received color image data here

def callback_depth(data):
    rospy.loginfo("Received Depth Image from Master")
    # Process the received depth image data here

def slave_listener():
    rospy.init_node('slave_listener', anonymous=True)
    rospy.Subscriber('/master/camera/color', Image, callback_color)
    rospy.Subscriber('/master/camera/depth', Image, callback_depth)
    rospy.spin()

if __name__ == '__main__':
    try:
        slave_listener()
    except rospy.ROSInterruptException:
        pass

