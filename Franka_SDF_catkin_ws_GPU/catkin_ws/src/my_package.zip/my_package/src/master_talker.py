#!/usr/bin/env python

import rospy
from sensor_msgs.msg import Image
import cv_bridge

def master_talker():
    rospy.init_node('master_talker', anonymous=True)
    color_pub = rospy.Publisher('/master/camera/color', Image, queue_size=10)
    depth_pub = rospy.Publisher('/master/camera/depth', Image, queue_size=10)

    # Initialize the OpenCV bridge to convert ROS Image messages to OpenCV images
    bridge = cv_bridge.CvBridge()

    # Replace the following callbacks with actual callbacks to receive the Realsense camera data
    def color_callback(data):
        color_pub.publish(data)

    def depth_callback(data):
        depth_pub.publish(data)

    # Replace the following subscribers with the actual topics from the Realsense camera
    rospy.Subscriber('/camera/color/image_raw', Image, color_callback)
    rospy.Subscriber('/camera/depth/image_rect_raw', Image, depth_callback)

    rospy.spin()

if __name__ == '__main__':
    try:
        master_talker()
    except rospy.ROSInterruptException:
        pass

